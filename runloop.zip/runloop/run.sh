#!/bin/bash
cd ..
sudo rm -rf ./nohup.out
sudo nohup ./appMain &